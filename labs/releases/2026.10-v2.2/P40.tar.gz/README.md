# 库存工作区 · C41 试做参考起点（P40）

发行版：2026.10-v2.2。这是 C41 明确前置的试做起点；不代表此前所有课程已连续完成。

需要 Node 24。在本目录执行一次 npm ci，再按课内说明执行 npm run lab -- start C41 和 npm run lab -- dev。打开终端给出的地址。跨课继续自己的源码，不自动复制答案。

暂停时在 notes/next.md 记录当前课、已改文件、观察结果和下一步。check 检查实际工作文件，不会标记网页课程完成。restore 只写新目录，非空则拒绝；compare 只读显示差异。

课程与升级说明：https://socoo123.github.io/js_web/labs/
