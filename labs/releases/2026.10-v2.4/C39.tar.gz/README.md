# 库存工作区 · C39 完成参考解

发行版：2026.10-v2.4。这是已完成的参考解。通常作为下一课的参考起点或用于补课对照；不是 C00 初始工程。

需要 Node 24。在本目录执行一次 npm ci，再按课内说明执行 npm run lab -- start C39 和 npm run lab -- dev。打开终端给出的地址。跨课继续自己的源码，不自动复制答案。

暂停时在 notes/next.md 记录当前课、已改文件、观察结果和下一步。check 检查实际工作文件，不会标记网页课程完成。restore 只写新目录，非空则拒绝；compare 只读显示差异。

课程与升级说明：https://socoo123.github.io/js_web/labs/
