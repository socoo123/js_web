# 库存工作区 · C00 初始工程

发行版：2026.10-v2.4。这是最小商品卡片骨架，后续能力由你逐章加入。

需要 Node 24。在本目录执行一次 npm ci，再按课内说明执行 npm run lab -- start C01 和 npm run lab -- dev。打开终端给出的地址。跨课继续自己的源码，不自动复制答案。

暂停时在 notes/next.md 记录当前课、已改文件、观察结果和下一步。check 检查实际工作文件，不会标记网页课程完成。restore 只写新目录，非空则拒绝；compare 只读显示差异。

课程与升级说明：https://socoo123.github.io/js_web/labs/
