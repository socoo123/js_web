# 库存工作区 · C00 初始工程

发行版：2026.10-v2.5。这是最小商品卡片骨架，后续能力由你逐章加入。

需要 Node 24。在本目录执行一次 npm ci，再按课内说明执行 npm run lab -- start C01 和 npm run lab -- dev。打开终端给出的地址。跨课继续自己的源码，不自动复制答案。

五个 Lab 起点为 C00/C10/C20/C36/C44；恢复的是该课完成态，不包含下一阶段的答案。L5 从 C44 接 C45–C48，回到保留的 src/react；adapters 留作对照。

暂停时在 notes/next.md 记录当前课、已改文件、观察结果和下一步。start 只选择任务，status 可跨终端查看；check 检查实际工作文件，不会标记网页课程完成。compare 只读显示差异，不应用补丁或改任务记录。

恢复示例：npm run lab -- restore C44 ../inventory-delivery。目标必须不存在或为普通空目录；非空目录、普通文件、符号链接均拒绝。先核对发行版和文件校验值，再写入新目录；当前源码、notes 和 .lab 均保留，坏任务记录也不妨碍另存恢复。进入新目录后用该版锁执行 npm ci，再 start 当前课。

课程与升级说明：https://socoo123.github.io/js_web/labs/
